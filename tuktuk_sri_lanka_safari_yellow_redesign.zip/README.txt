TUK TUK SRI LANKA SAFARI — YELLOW REDESIGN

Files:
- index.html
- images/ (your uploaded Sri Lanka photos)

FREE PUBLISHING WITH GITHUB PAGES
1. Create/sign in to GitHub.
2. Create a public repository named tuktuk-sri-lanka-safari.
3. Upload index.html AND the complete images folder (keep the folder name exactly "images").
4. Go to Settings > Pages.
5. Select Deploy from a branch, branch main, folder /(root), then Save.
6. Wait for GitHub Pages to publish and use the live URL shown there.

SEO
- Replace the canonical URL placeholder with your real GitHub Pages URL once published.
- Add the website to Google Search Console and verify ownership.
- Add a sitemap after the final URL is known.
- Rankings are not guaranteed; publish useful original content and collect genuine customer reviews.

IMPORTANT BUSINESS DETAILS
- WhatsApp: +94 76 556 0424
- Instagram: @tuktuksrilankasafari
- Operating base: Kandy, Sri Lanka
- 5, 7 and 10 day tuk tuk tours with driver
- Local sightseeing guidance included
- Vehicle insurance included (not personal travel/medical insurance)
- Confirm all route details, daily hours, availability and any exclusions in a written quote before booking.
- Meals, accommodation, entrance tickets, fuel and other costs are not claimed as included unless your quote says so.

The supplied photos are included locally in the images folder, so the site does not rely on external photo URLs.
